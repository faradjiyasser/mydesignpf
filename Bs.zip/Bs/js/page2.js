/*small pic appears animation*/


function designsmallpicappear() {
    document.getElementById("designsmallpicanimation0").style.animationName= "designsmallpicanimation0";
    document.getElementById("designsmallpicanimation1").style.animationName= "designsmallpicanimation1";
    document.getElementById("designsmallpicanimation2").style.animationName= "designsmallpicanimation1";
}
function designsmallpicfade() {
    document.getElementById("designsmallpicanimation0").style.animationName= "designsmallpicanimation02";
    document.getElementById("designsmallpicanimation1").style.animationName= "designsmallpicanimation12";
    document.getElementById("designsmallpicanimation2").style.animationName= "designsmallpicanimation12";

}
/*aboutme appears animation*/
function aboutmeappears1() {
    document.getElementById("aboutline1").style.animationName= "aboutlinesappear1";
    document.getElementById("aboutline2").style.animationName= "aboutlinesappear2";
    document.getElementById("aboutme12").style.animationName= "aboutappear";
    document.getElementById("aboutme22").style.animationName= "aboutappear";
    document.getElementById("freelancer").style.animationName= "freelanceappears";
    document.getElementById("resumebutton").style.animationName= "resumebuttonappears";
}
function aboutmedisappears1() {
    document.getElementById("aboutline1").style.animationName= "aboutlinesdisappear1";
    document.getElementById("aboutline2").style.animationName= "aboutlinesdisappear2";
    document.getElementById("aboutme12").style.animationName= "aboutdisappear";
    document.getElementById("aboutme22").style.animationName= "aboutdisappear";
    document.getElementById("freelancer").style.animationName= "freelancedisappears";
    document.getElementById("resumebutton").style.animationName= "resumebuttondisappears";
}

function lnameappears1() {
    document.getElementById("lname1").style.animationName= "lnameappear1";
    document.getElementById("lname2").style.animationName= "lnameappear1";
    document.getElementById("lnamedes1").style.animationName= "aboutlinesappear1";
    document.getElementById("lnamedes2").style.animationName= "aboutlinesappear2";
    document.getElementById("hydro").style.animationName= "hydroappears";
}

function lnamedisappears1() {
    document.getElementById("lname1").style.animationName= "lnamedisappear1";
    document.getElementById("lname2").style.animationName= "lnamedisappear1";
    document.getElementById("lnamedes1").style.animationName= "aboutlinesdisappear1";
    document.getElementById("lnamedes2").style.animationName= "aboutlinesdisappear2";
    document.getElementById("hydro").style.animationName= "hydrodisappears";
}