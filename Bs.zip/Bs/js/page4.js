function contactpicappears() {
    document.getElementById("contactpic").style.animationName= "contactpicappears";
    document.getElementById("smallpicanimation1contact").style.animationName= "smallpiccontactdis";
    document.getElementById("smallpicanimation2contact").style.animationName= "smallpiccontactdis";
}
function contactpicdisappears() {
    document.getElementById("contactpic").style.animationName= "contactpicdisappears";
    document.getElementById("smallpicanimation1contact").style.animationName= "smallpiccontact";
    document.getElementById("smallpicanimation2contact").style.animationName= "smallpiccontact";
}
/* writing */
function writingappears() {
    document.getElementById("contactme").style.animationName= "contactappears"; 
    document.getElementById("contactme2").style.animationName= "contactappears"; 
    document.getElementById("contactline1").style.animationName= "contactlinesappear1"; 
    document.getElementById("contactline2").style.animationName= "contactlinesappear2"; 
    document.getElementById("clickcontacts").style.animationName= "clickcontactsappears"; 
    document.getElementById("mynumber").style.animationName= "clickcontactsappears"; 
}
function writingdisappears() {
    document.getElementById("contactme").style.animationName= "contactdisappears"; 
    document.getElementById("contactme2").style.animationName= "contactdisappears"; 
    document.getElementById("contactline1").style.animationName= "contactlinesdisappear1"; 
    document.getElementById("contactline2").style.animationName= "contactlinesdisappear2"; 
    document.getElementById("clickcontacts").style.animationName= "clickcontactsdisappears"; 
    document.getElementById("mynumber").style.animationName= "clickcontactsdisappears"; 
}





